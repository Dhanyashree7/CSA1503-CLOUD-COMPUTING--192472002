# Cloud-Based Online Education Service

Simple implementation for the CSA15 Cloud Computing and Big Data Analytics assignment.

## Features
1. Cloud architecture visualization
2. Server virtualization resource allocation demo
3. Web service / REST-style JSON demo
4. IaaS, PaaS, SaaS and XaaS comparison
5. Simple student enrollment service
6. Results page

## Run in VS Code

Open the terminal inside this folder and run:

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

A browser window will open automatically.

## Project explanation
This is a simulation for academic demonstration. It does not create paid cloud infrastructure.

## Assignment mapping
- Task 1: Cloud concept and evolution -> report/presentation
- Task 2: Hardware evolution -> report/presentation
- Task 3: Internet software evolution -> report/presentation
- Task 4: Virtualization -> Virtualization Demo
- Task 5: Web Services -> Web Service Demo
- Task 6: IaaS -> Service Model page
- Task 7: PaaS -> Service Model page
- Task 8: SaaS -> Service Model page
- Task 9: XaaS -> Service Model page
- Task 10: Comparison and final architecture -> Architecture + Service Model pages
