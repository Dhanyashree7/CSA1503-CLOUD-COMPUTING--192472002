import streamlit as st
import pandas as pd
import json
from datetime import datetime

st.set_page_config(page_title="Cloud Education Service", page_icon="☁️", layout="wide")

st.title("☁️ Cloud-Based Online Education Service")
st.caption("Simple implementation for CSA15 – Cloud Computing and Big Data Analytics")

st.sidebar.header("Navigation")
page = st.sidebar.radio("Select Module", [
    "Home", "Cloud Architecture", "Virtualization Demo",
    "Web Service Demo", "IaaS / PaaS / SaaS / XaaS",
    "Student Service", "Results"
])

if page == "Home":
    st.header("Online Education Cloud")
    st.write("This demo shows a simple cloud architecture for an online education organization.")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Students", "10,000")
    c2.metric("Courses", "250")
    c3.metric("Virtual Machines", "4")
    c4.metric("Availability Target", "99.9%")
    st.subheader("Main Services")
    st.markdown("""
    - **IaaS:** Virtual machines, storage and networking
    - **PaaS:** Application development and deployment platform
    - **SaaS:** Learning management, video meetings and collaboration
    - **XaaS:** Combination of cloud services
    """)
    st.info("The project is an educational simulation. It does not create real cloud resources.")

elif page == "Cloud Architecture":
    st.header("Proposed Cloud Architecture")
    st.code("""
Students / Teachers
        |
        v
   Internet / HTTPS
        |
        v
   Web Application
        |
   +----+----+
   |         |
  PaaS     Web APIs
   |         |
   v         v
 Database   SaaS Services
   |
   v
Cloud Storage
   |
   v
Virtualization Layer
   |
Hypervisor
   |
+---------- Physical Cloud Server ----------+
| VM 1: LMS | VM 2: Exams | VM 3: API | VM 4: DB |
+--------------------------------------------+
    """)
    st.subheader("Why this architecture?")
    st.write("Virtual machines share physical hardware, while PaaS simplifies application deployment and SaaS provides ready-to-use educational tools. Cloud storage handles course files and videos.")

elif page == "Virtualization Demo":
    st.header("Server Virtualization Demonstration")
    st.write("Move the sliders to simulate resource allocation among virtual machines.")
    total_cpu = 100
    total_ram = 100
    lms = st.slider("LMS VM CPU (%)", 0, 70, 40)
    exam = st.slider("Exam VM CPU (%)", 0, 70, 25)
    api = st.slider("API VM CPU (%)", 0, 70, 20)
    used = lms + exam + api
    st.metric("CPU Used", f"{used}%")
    st.metric("CPU Available", f"{max(0, total_cpu-used)}%")
    if used <= 100:
        st.success("Resource allocation is within the physical server capacity.")
    else:
        st.error("Over-allocation detected. Reduce VM resources.")
    data = pd.DataFrame({
        "Virtual Machine": ["LMS VM", "Exam VM", "API VM"],
        "CPU Allocation (%)": [lms, exam, api]
    })
    st.bar_chart(data.set_index("Virtual Machine"))

elif page == "Web Service Demo":
    st.header("Web Service / REST API Demonstration")
    st.write("A simple simulated API shows how applications exchange data over a network.")
    student = st.text_input("Student Name", "Gayathri")
    course = st.selectbox("Course", ["Cloud Computing", "Big Data", "Python", "Cyber Security"])
    if st.button("Send API Request"):
        response = {
            "status": "success",
            "student": student,
            "course": course,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        st.success("API response received")
        st.json(response)

elif page == "IaaS / PaaS / SaaS / XaaS":
    st.header("Cloud Service Model Comparison")
    data = pd.DataFrame([
        ["IaaS", "High", "User manages OS/apps", "High", "Pay for resources", "VM, storage, network"],
        ["PaaS", "Medium", "Provider manages platform", "High", "Pay for platform/use", "Develop and deploy apps"],
        ["SaaS", "Low", "Provider manages almost everything", "High", "Subscription/use", "Ready-to-use software"],
        ["XaaS", "Varies", "Shared responsibility", "Very High", "Usage based", "Combination of services"],
    ], columns=["Model", "Control", "Management", "Scalability", "Cost", "Example"])
    st.dataframe(data, use_container_width=True)
    st.subheader("Recommended combination")
    st.write("Use IaaS for flexible infrastructure, PaaS for developing the education portal, SaaS for collaboration/communication, and XaaS to combine services.")

elif page == "Student Service":
    st.header("Simple Online Education Service")
    name = st.text_input("Student Name")
    email = st.text_input("Email")
    course = st.selectbox("Enroll in", ["Cloud Computing", "Big Data Analytics", "Python Programming"])
    if st.button("Enroll"):
        if name and email:
            st.success(f"{name} enrolled successfully in {course}.")
        else:
            st.warning("Enter student name and email.")

elif page == "Results":
    st.header("Implementation Results")
    results = {
        "Cloud architecture": "Implemented as a visual simulation",
        "Virtualization": "VM resource allocation demonstrated",
        "Web services": "REST-style JSON exchange demonstrated",
        "IaaS/PaaS/SaaS/XaaS": "Compared and recommended",
        "Education service": "Student enrollment demo implemented",
        "Deployment": "Ready to run locally with Streamlit"
    }
    st.json(results)
    st.success("Implementation completed successfully.")
